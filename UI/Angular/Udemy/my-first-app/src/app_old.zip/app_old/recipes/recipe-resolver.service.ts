import { Resolve, ActivatedRouteSnapshot, ActivatedRoute, RouterStateSnapshot } from '@angular/router';
import { Recipe } from './recipe.model';
import { Injectable } from '@angular/core';
import { DataStorageService } from '../shared/data-storage.service';
import { RecipeService } from './recipe.service';

@Injectable({providedIn : 'root'})
export class RecipeResolverService implements Resolve<Recipe[]> 
{
    constructor(private dataStorageService : DataStorageService,private recipeService : RecipeService){}

    resolve(activateRoute : ActivatedRouteSnapshot,activatedState : RouterStateSnapshot)
    {
        if(this.recipeService.getRecipes().length === 0)
        {
            return this.dataStorageService.onFetchRecipe();
        }
    }
}