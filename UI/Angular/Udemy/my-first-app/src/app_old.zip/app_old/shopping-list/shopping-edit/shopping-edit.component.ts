import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  OnDestroy
} from '@angular/core';

import { Ingredient } from '../../shared/ingredient.model';
import { ShoppingListService } from '../shopping-list.service';
import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css']
})
export class ShoppingEditComponent implements OnInit,OnDestroy {
  // @ViewChild('nameInput', { static: false }) nameInputRef: ElementRef;
  // @ViewChild('amountInput', { static: false }) amountInputRef: ElementRef;
  @ViewChild('shoppingForm', { static: false }) shoppingForm: NgForm;
  ingredient : Ingredient;
  editSubscription : Subscription;
  editMode : boolean = false;
  editIndex : number;
  constructor(private slService: ShoppingListService) { }

  ngOnInit() 
  {
    this.editSubscription = this.slService.editIngredient.subscribe(index =>
      {
        this.editIndex = index;
        this.editMode=true;
        this.ingredient = this.slService.getIngredient(index);
        this.shoppingForm.setValue(
          { 'name' : this.ingredient.name,
            'amount' : this.ingredient.amount
          }); 
      })
  }

  onAddItem(form : NgForm) {
    // const ingName = this.nameInputRef.nativeElement.value;
    // const ingAmount = this.amountInputRef.nativeElement.value;
    const ingName = form.form.get('name').value;
    const ingAmount = form.form.get('amount').value;
    const newIngredient = new Ingredient(ingName, ingAmount);

    if(this.editMode)
    {
      this.slService.setIngredient(this.editIndex,newIngredient);
    }
    else
    {
      this.slService.addIngredient(newIngredient);
    }
    this.onClear();
  }

  onClear()
  {
    this.shoppingForm.reset();
    this.editMode=false;
  }

  onDelete()
  {
    this.slService.removeIngredient(this.editIndex);
    this.onClear();
  }

  ngOnDestroy()
  {
    this.editSubscription.unsubscribe();
  }
}
