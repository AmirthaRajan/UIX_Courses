import { Component } from '@angular/core';
import { DataStorageService } from '../shared/data-storage.service';
import { RecipeService } from '../recipes/recipe.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent {

  constructor(private storageService : DataStorageService,private recpieService : RecipeService){}

  onSave()
  {
    this.storageService.onSaveRecipe();
  }

  onFetch()
  {
    return this.storageService.onFetchRecipe().subscribe();
  }
}
