import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';
import { RecipeService } from '../recipes/recipe.service';
import { Recipe } from '../recipes/recipe.model';
import { map, tap } from 'rxjs/operators';

@Injectable({providedIn : 'root'})
export class DataStorageService
{
    constructor(private http : HttpClient,private recipeService : RecipeService){}

    onSaveRecipe()
    {
        const recipe = this.recipeService.getRecipes();
        this.http.put("https://angular-burget.firebaseio.com/recipes.json",recipe).subscribe(responseData => {
            console.log(responseData);
        });
    }

    onFetchRecipe()
    {
        return this.http.get<Recipe[]>("https://angular-burget.firebaseio.com/recipes.json", {
            responseType : 'json',
            observe : 'body'
        }).pipe(map ( response => {
            return response.map( res => { return {...res , ingredients : res.ingredients ? res.ingredients : []}; });
        }),tap( recpies => {
            this.recipeService.setRecipe(recpies);
            }
            ))
    }
}